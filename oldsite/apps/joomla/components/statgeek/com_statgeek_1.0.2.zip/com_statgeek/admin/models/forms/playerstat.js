/**
 *	player : Validate
 *	Filename : playerstat.js
 *
 *	Author : Nate Mason
 *	Component : Stat Geek
 *
 *	Copyright : Copyright (C) 2013. All Rights Reserved
 *	License : GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 *
 **/
window.addEvent('domready', function() {
});